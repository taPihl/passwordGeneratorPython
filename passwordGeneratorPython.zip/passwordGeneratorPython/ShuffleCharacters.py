import DataTypesAndObjects

def shuffle(ruleset, str_inputString):
    int_lengthRuleset = len(ruleset.arr_int_ruleset)
    int_lengthInputString = len(str_inputString)
    str_returnValue = ""
    str_tempString = ""
    y = 0

    for x in range(int_lengthRuleset):
        if y > int_lengthInputString - 1:
            y = 0
        str_tempString = str_tempString + str_inputString[y]
        y = y + 1

    arr_characters = characters()

    for x in range(int_lengthRuleset):
        for z in range(26):
            if str_tempString[x] == arr_characters[0][z]:
                break
            elif str_tempString[x] == arr_characters[1][z]:
                break
        else:
            for z in range(10):
                if str_tempString[x] == arr_characters[2][z]:
                    break

        if ruleset.arr_int_ruleset[x] == 1: #capital letter
            k = returnRandomNumber_0_to_25(z, x)
            str_returnValue = str_returnValue + arr_characters[0][k]
        elif ruleset.arr_int_ruleset[x] == 2: #number
            k = returnRandomNumber_0_to_9(z, x)
            str_returnValue = str_returnValue + arr_characters[2][k]
        elif ruleset.arr_int_ruleset[x] == 3: #small letter
            k = returnRandomNumber_0_to_25(z, x)
            str_returnValue = str_returnValue + arr_characters[1][k]

    return str_returnValue

def characters():
    arr_array0 = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    arr_array1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r","s", "t", "u", "v", "w", "x", "y", "z"]
    arr_array2 = ["0","1","2","3","4","5","6","7","8","9"]

    returnValue = [arr_array0,arr_array1,arr_array2]

    return returnValue

def randomNumbers_26():
    arr_array0 = [22, 21, 15, 21, 18, 13, 22, 10, 10, 8, 9, 3, 22, 17, 19, 25, 23, 5, 21, 25, 15, 9, 5, 14, 11, 9]
    arr_array1 = [6, 12, 4, 21, 22, 1, 11, 13, 14, 3, 1, 2, 2, 8, 9, 24, 4, 18, 4, 9, 9, 21, 20, 15, 18, 3]
    arr_array2 = [1, 13, 13, 2, 18, 19, 6, 16, 24, 2, 18, 8, 1, 20, 1, 11, 9, 15, 25, 20, 4, 5, 7, 6, 0, 5]
    arr_array3 = [21, 11, 21, 1, 21, 12, 1, 7, 7, 6, 20, 15, 1, 7, 10, 0, 7, 22, 10, 8, 9, 15, 13, 14, 3, 3]
    arr_array4 = [2, 21, 4, 8, 12, 16, 11, 12, 15, 3, 13, 17, 20, 0, 22, 20, 6, 19, 0, 21, 15, 0, 23, 9, 16, 20]
    arr_array5 = [7, 24, 21, 13, 15, 8, 23, 25, 15, 8, 4, 7, 11, 5, 0, 10, 3, 1, 18, 13, 4, 7, 20, 14, 19, 4]
    arr_array6 = [5, 12, 7, 18, 17, 9, 12, 21, 3, 14, 18, 14, 15, 0, 24, 3, 12, 15, 15, 16, 1, 16, 24, 24, 20, 11]
    arr_array7 = [25, 23, 8, 18, 12, 0, 16, 1, 21, 5, 25, 6, 21, 16, 18, 8, 25, 12, 20, 2, 23, 3, 24, 3, 18, 2]
    arr_array8 = [25, 1, 6, 0, 6, 21, 23, 7, 22, 2, 5, 0, 21, 18, 19, 10, 19, 17, 7, 13, 5, 17, 16, 17, 6, 2]
    arr_array9 = [8, 8, 7, 4, 22, 20, 4, 4, 13, 2, 21, 2, 11, 3, 23, 12, 23, 16, 16, 8, 17, 6, 22, 9, 7, 14]
    returnValue = [arr_array0,arr_array1,arr_array2,arr_array3,arr_array4,arr_array5,arr_array6,arr_array7,arr_array8,arr_array9]
    return returnValue

def randomNumbers_10():
    arr_array0 = [1, 6, 3, 5, 7, 7, 5, 6, 1, 5]
    arr_array1 = [8, 2, 5, 6, 6, 1, 8, 8, 9, 2]
    arr_array2 = [7, 6, 4, 2, 6, 1, 1, 2, 5, 1]
    arr_array3 = [8, 8, 2, 8, 8, 7, 8, 1, 1, 7]
    arr_array4 = [1, 5, 2, 5, 3, 4, 6, 2, 6, 8]
    arr_array5 = [5, 7, 3, 4, 5, 6, 7, 7, 8, 6]
    arr_array6 = [2, 5, 6, 5, 6, 4, 8, 1, 8, 2]
    arr_array7 = [1, 3, 5, 4, 7, 2, 6, 9, 8, 8]
    arr_array8 = [5, 2, 4, 4, 2, 8, 9, 2, 1, 1]
    arr_array9 = [9, 1, 4, 1, 9, 8, 7, 3, 2, 7]
    returnValue = [arr_array0,arr_array1,arr_array2,arr_array3,arr_array4,arr_array5,arr_array6,arr_array7,arr_array8,arr_array9]
    return returnValue

def returnRandomNumber_0_to_25(int_startPoint, int_numberOfIterations):
    arr_randomNumbers = randomNumbers_26()
    int_tempStartPoint = int_startPoint
    y = 0

    while int_tempStartPoint > 25:
        int_tempStartPoint = int(int_tempStartPoint / 2)

    if int_numberOfIterations > 0:
        for x in range(int_numberOfIterations):
            if y > 9:
                y = 0
            if x == 0:
                int_value = arr_randomNumbers[y][int_tempStartPoint]
            elif x > 0:
                int_value = arr_randomNumbers[y][int_value]
            y = y + 1
    elif int_numberOfIterations <= 0:
        int_value = arr_randomNumbers[0][int_tempStartPoint]

    return int_value

def returnRandomNumber_0_to_9(int_startPoint, int_numberOfIterations):
    arr_randomNumbers = randomNumbers_10()
    int_tempStartPoint = int_startPoint
    y = 0

    while int_tempStartPoint > 9:
        int_tempStartPoint = int(int_tempStartPoint / 2)

    if int_numberOfIterations > 0:
        for x in range(int_numberOfIterations):
            if y > 9:
                y = 0
            if x == 0:
                int_value = arr_randomNumbers[y][int_tempStartPoint]
            elif x > 0:
                int_value = arr_randomNumbers[y][int_value]
            y = y + 1
    elif int_numberOfIterations <= 0:
        int_value = arr_randomNumbers[0][int_tempStartPoint]

    return int_value