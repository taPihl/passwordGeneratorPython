import DataTypesAndObjects

def createRuleSet(configSet):
    #init internal variables:
    int_length = configSet.int_length
    int_nCaps = configSet.int_nCaps
    int_indexFirstCap = configSet.int_indexFirstCap
    int_nNumbers = configSet.int_nNumbers
    int_indexFirstNumber = configSet.int_indexFirstNumber

    #init return value as a ruleset object:
    returnValue = DataTypesAndObjects.ruleSet([])
    #initialize temp variables:
    arr_int_temp = []
    for y in range(int_length):
        arr_int_temp.append(0)
    int_tempCaps = 0
    int_tempNumbers = 0
    bool_pauseCaps = False
    bool_continue = False
    bool_canAddCaps = False
    bool_canAddNumbers = False
    #ruleset array member value indicates which character must be generated:
    #1=Capital letter
    #2=number
    #3=small letter

    # adding capital letters takes priority
    # all characters are caps?
    if int_nCaps >= int_length:
        for x in range(int_length):
            arr_int_temp[x] = 1
    # all characters are not caps:
    else:
        for x in range(int_length):
            bool_continue = False
            # add capitals
            if int_tempCaps < int_nCaps:
                if int_tempCaps == 0 and x == int_indexFirstCap:
                    arr_int_temp[x] = 1
                    int_tempCaps = int_tempCaps + 1
                    bool_continue = True
                    # there must be another character between two capital letters
                    bool_pauseCaps = True
                    bool_canAddCaps = True
                if bool_pauseCaps == False and bool_continue == False and bool_canAddCaps == True:
                    arr_int_temp[x] = 1
                    int_tempCaps = int_tempCaps + 1
                    bool_continue = True
                    bool_pauseCaps = True
                elif bool_pauseCaps == True and bool_continue == False:
                    bool_pauseCaps = False

            # add numbers: they takes second highest priority
            if bool_continue == False:
                if int_tempNumbers < int_nNumbers:
                    if int_tempNumbers == 0 and x == int_indexFirstNumber:
                        arr_int_temp[x] = 2
                        int_tempNumbers = int_tempNumbers + 1
                        bool_continue = True
                        bool_canAddNumbers = True
                    else:
                        if bool_canAddNumbers == True:
                            arr_int_temp[x] = 2
                            int_tempNumbers = int_tempNumbers + 1
                            bool_continue = True

            # add small letters: they take lowest priority
            if bool_continue == False:
                arr_int_temp[x] = 3

    returnValue.arr_int_ruleset = arr_int_temp

    return returnValue
















