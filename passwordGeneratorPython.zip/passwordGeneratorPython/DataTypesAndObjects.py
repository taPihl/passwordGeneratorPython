class configurationSet:
    def __init__(self, int_length, int_nCaps, int_indexFirstCap, int_nNumbers, int_indexFirstNumber):
        self.int_length = int_length
        self.int_nCaps = int_nCaps
        self.int_indexFirstCap = int_indexFirstCap
        self.int_nNumbers = int_nNumbers
        self.int_indexFirstNumber = int_indexFirstNumber

class ruleSet:
    def __init__(self, arr_int_ruleset):
        self.arr_int_ruleset = arr_int_ruleset