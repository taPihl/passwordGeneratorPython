
import DataTypesAndObjects
import ReadConfigFile
import CreateRuleSet
import ShuffleCharacters

# main program run
if __name__ == '__main__':
    while True:
        # get the input string which is being used for creating password
        str_inputString = input("Give key string: ")

        # read config file
        configSet = ReadConfigFile.readProjectConfigFile("PWGEN_CONFIG.cfg")
        #print(configSet)

        # generate ruleset according to config file
        ruleset = CreateRuleSet.createRuleSet(configSet)
        #print(ruleset)

        # generate password
        str_password = ShuffleCharacters.shuffle(ruleset, str_inputString)

        print(str_password)

        # ask whether to quit or generate another password:
        continueCommand = input("Create another password? (Y/N): ")
        if continueCommand == "Y" or continueCommand == "y" or continueCommand == "Yes" or continueCommand == "yes":
            pass
        else:
            break

