import configparser
import DataTypesAndObjects

def readProjectConfigFile(fileName):
    #introduce parcer
    parser = configparser.ConfigParser()
    #initialize returnvalue as a configuration set object
    returnValue = DataTypesAndObjects.configurationSet(0,0,0,0,0)

    parser.read(fileName)

    #get values for returnvalue instance from config file
    returnValue.int_length = int(parser.get("config", "length"))
    returnValue.int_nCaps = int(parser.get("config", "numberOfCaps"))
    returnValue.int_indexFirstCap = int(parser.get("config", "indexOfFirstCap"))
    returnValue.int_nNumbers = int(parser.get("config", "numberOfNumbers"))
    returnValue.int_indexFirstNumber = int(parser.get("config", "indexOfFirstNumber"))

    return returnValue





